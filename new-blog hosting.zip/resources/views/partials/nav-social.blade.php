 <!-- Modals -->
 <!-- Off canvas social menu -->
 <nav id="offCanvasMenu" class="off-canvas-menu">
     <button type="button" class="close" aria-label="Close" data-dismiss="offCanvasMenu">
         <span aria-hidden="true">&times;</span>
     </button>
     <ul class="oleez-social-menu">
         <li>
             <a href="#!" class="oleez-social-menu-link">Facebook</a>
         </li>
         <li>
             <a href="#!" class="oleez-social-menu-link">Instagram</a>
         </li>
         <li>
             <a href="#!" class="oleez-social-menu-link">Behance</a>
         </li>
         <li>
             <a href="#!" class="oleez-social-menu-link">Dribbble</a>
         </li>
         <li>
             <a href="#!" class="oleez-social-menu-link">Email</a>
         </li>
     </ul>
 </nav>
