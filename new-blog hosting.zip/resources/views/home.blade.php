@extends('layouts.main')

@section('container')
@include('layouts.main-content')
@endsection
