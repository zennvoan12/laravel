// Wait for window load
$(window).on('load', function () {
    // Animate loader off screen
    $(".oleez-loader").fadeOut("slow");;
});